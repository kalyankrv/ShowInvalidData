package data.validation.tests;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Test;

import data.validation.ValidateData;

public class ValidateDataTests {

	@Test
	public void shouldReturnEmptyArrayWhenAllDataIsValid() throws ParseException {
		String jsonString = ("[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"001\""
				+ "},"
				+ "{\"name\":\"Julia Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"44109\","
				+ "\"id\":\"002\""
				+ "}]");
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        assertEquals(0, validateData.getIdsOfInvalidRecords(jsonArray).size());
	}
	@Test
	public void shouldReturnRecordWhichHasNameValueBlank() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"003\""
				+ "},"
				+ "{\"name\":\"\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"44109\","
				+ "\"id\":\"004\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("004", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasNameValueNull() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"005\""
				+ "},"
				+ "{\"name\":null,"
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"44109\","
				+ "\"id\":\"006\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("006", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasAddressValueBlank() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"007\""
				+ "},"
				+ "{\"name\":\"Julia Roberts\","
				+ "\"address\":\"\","
				+ "\"zip\":\"44109\","
				+ "\"id\":\"008\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("008", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasAddressValueNull() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"009\""
				+ "},"
				+ "{\"name\":\"Julia Roberts\","
				+ "\"address\":null,"
				+ "\"zip\":\"44109\","
				+ "\"id\":\"010\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("010", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasZipValueBlank() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"011\""
				+ "},"
				+ "{\"name\":\"Julia Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"\","
				+ "\"id\":\"012\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("012", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasZipValueNull() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"013\""
				+ "},"
				+ "{\"name\":\"Julia Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":null,"
				+ "\"id\":\"014\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("014", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasZipWithAlphabetsOnly() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"015\""
				+ "},"
				+ "{\"name\":\"Julie Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"aaaaa\","
				+ "\"id\":\"016\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("016", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasFourDigitZip() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"017\""
				+ "},"
				+ "{\"name\":\"Julie Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"1234\","
				+ "\"id\":\"018\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("018", firstItem);
	}
	@Test
	public void shouldReturnRecordWhichHasEightDigitZip() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565\","
				+ "\"id\":\"019\""
				+ "},"
				+ "{\"name\":\"Julie Roberts\","
				+ "\"address\":\"5037 Providence Bouled\","
				+ "\"zip\":\"12345-678\","
				+ "\"id\":\"020\""
				+ "}]";
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        String firstItem = output.iterator().next();
        assertEquals(1, output.size());
        assertEquals("020", firstItem);
	}
	@Test
	public void shouldNotReturnRecordWhichHasNineDigitValidZip() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565-4534\","
				+ "\"id\":\"021\""
				+ "}]";
		
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        assertEquals(0, output.size());
	}
	@Test
	public void shouldReturnDuplicateRecords() throws ParseException {
		String jsonString = "[{"
				+ "\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565-4534\","
				+ "\"id\":\"022\""
				+ "},"
				+ "{\"name\":\"Daniel Richards\","
				+ "\"address\":\"166 High Road\","
				+ "\"zip\":\"17565-4534\","
				+ "\"id\":\"023\""
				+ "}]";
		
		JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(jsonString);
        
        ValidateData validateData = new ValidateData();
        List<String> output = validateData.getIdsOfInvalidRecords(jsonArray);
        
        assertEquals(2, output.size());
	}	
}
