package data.validation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ValidateData {
	public static final String postCodeRegex = "^[0-9]{5}(?:-[0-9]{4})?$";

	public List<String> getIdsOfInvalidRecords(JSONArray array) {
		List<String> output = new ArrayList<String>();

        Iterator<JSONObject> i = array.iterator();

        // Take each value from the JSON array separately
        while (i.hasNext()) {
            JSONObject innerObj = (JSONObject) i.next();
            Object id = innerObj.get("id");
            Object name = innerObj.get("name");
            Object address = innerObj.get("address");
            Object zip = innerObj.get("zip");
            
            if(!isEmptyString(id) && 
            		(isEmptyString(name)
            		|| isEmptyString(address)
            		|| isEmptyString(zip)
            		|| !Pattern.matches(postCodeRegex, zip.toString())))
            	output.add(id.toString());
            else {
            	// Compare each object with every other object in the array for duplicates
            	for(int a = 0; a < array.size(); a++) {
                	JSONObject obj = (JSONObject) array.get(a);
                	Object objId = obj.get("id");
                    Object objName = obj.get("name");
                    Object objAddress = obj.get("address");
                    Object objZip = obj.get("zip");
                	if(!isEmptyString(objId)
                			&& !isEmptyString(objName)
                    		&& !isEmptyString(objAddress)
                    		&& !isEmptyString(objZip))
    	            	if(!objId.toString().equals(id.toString())
    	            			&& objName.toString().equals(name.toString())
    	            			&& objAddress.toString().equals(address.toString())
    	            			&& objZip.toString().equals(zip.toString()))
    	            		output.add(objId.toString());
            	}
            }
        }
        
		return output;
	}
	
	private boolean isEmptyString(Object object) {
		return object == null || object.toString().isEmpty();
	}
}
