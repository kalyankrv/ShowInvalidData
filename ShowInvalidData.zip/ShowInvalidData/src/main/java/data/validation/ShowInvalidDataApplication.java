package data.validation;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ShowInvalidDataApplication {
	public static final String JSON_DATA_FILE = "data.json";

	/**
	 * 
	 * data.json is expected to be in the current directory
	 * @throws IOException if read of the data.json has issues
	 * @throws ParseException 
	 * 
	 */
	public static void main(String[] args) throws IOException, ParseException {
		try {
			URL path = ClassLoader.getSystemResource(JSON_DATA_FILE);
			if (path != null) {
				
				FileReader reader = new FileReader(path.getFile());
				
				JSONParser jsonParser = new JSONParser();
		        JSONArray jsonArray = (JSONArray) jsonParser.parse(reader);

		        ValidateData validateData = new ValidateData();
		        List<String> ids = validateData.getIdsOfInvalidRecords(jsonArray);
		        
		        if(ids.size() == 0) {
		        	System.out.println("No invalid data found");
		        	return;
		        }
		        
		        for(String id : ids) {
		            System.out.println(id);
		        }
			} else {
				System.out.println(JSON_DATA_FILE + " is not found");
			}
		} catch (ParseException pe) {
			System.out.println("Unable to parse the " + JSON_DATA_FILE + " file");
		}
	}
}
